<template>
	<main class="h-full w-full flex-col flex items-center justify-center">
		<div
			class="search-area w-full flex justify-around items-center flex-col"
		>
			<h1 class="text-gray-800 text-5xl relative top-20 font-medium">
				High Confidence Drug-Target Database
			</h1>
			<section class="w-3/5 h-14 flex relative">
				<input
					v-model="searchValue"
					placeholder="drug: Aspirin;gene: EGFR"
					class="outline-none bg-slate-50 w-4/5 h-full rounded-l-md block box-border px-6 text-lg border border-slate-500 focus:border-2 focus:border-slate-800 focus:bg-slate-100"
					@keyup.enter="toSearch"
				/>

				<button
					class="h-full w-1/5 bg-slate-800 text-white text-2xl rounded-r-md active:bg-slate-700"
					@click="toSearch"
				>
					Search
				</button>
			</section>
		</div>

		<section class="w-full h-max flex flex-col bg-slate-200 px-80 py-20">
			<h1
				class="text-3xl font-bold my-8 box-border"
			>
				Introduction
			</h1>
			<p class="first-letter:ml-8 text-lg">
				<span class="font-semibold"
					>HCDT (High Confidence Drug-Target Database)</span
				>is a combined database that provides validated interactions
				between drugs and target genes. The current version of HCDT
				includes 69,608 drugs, 6,393 genes and 138,333 drug-gene
				associations. The data are collected from 8 databases such as
				BindingDB, ChEMBL, Drugbank, etc. The SMILES Format is used to
				identify each drug molecule and the gene official symbol is used
				to identify each target gene. The target genes can be queried
				for each drug and the drugs can be queried for each gene in
				HCDT.
			</p>
		</section>

		<section
			class="w-full h-max py-5 flex flex-col bg-slate-200 box-border px-80"
		>
			<div class="w-full">
				<el-carousel height="400px" trigger="click" :autoplay="false" arrow="always">
					<el-carousel-item
						v-for="item in list.references"
						:key="item.id"
					>
						<div class="w-full h-full flex">
							<img :src="item.url" @click="toStatistics(item.to)" class="h-full bg-white first:cursor-pointer" style="width: 520px;" />
							<p class="box-border px-4 grow">
                <h3 class="text-2xl font-bold text-gray-800">Description: </h3>
                <p class="text-lg">{{ item.description }}</p>
              </p>
						</div>
					</el-carousel-item>
				</el-carousel>
			</div>
		</section>
	</main>
</template>

<script setup>
import { reactive, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import mockjs from 'mockjs'
const Mock = mockjs.Random
const router = useRouter()
const searchValue = ref('')
const showSuggest = ref(false)
watch(() => {
	showSuggest.value = searchValue.value ? true : false
})

const toStatistics = to => {
	if (!to) { return ; }
	router.push(to)
} 

const toSearch = () => {
	const [type, value] = searchValue.value.trim().split(':')
	// location.href = "#/search?type=drug&value=123"
	router.push({ name: 'Search', query: { type: type.trim(), value: value.trim() },params:{refresh: true} })
}

const list = reactive({
	search: [
		{
			id: Mock.id(),
			title: Mock.title(),
		},
		{
			id: Mock.id(),
			title: Mock.title(),
		},
		{
			id: Mock.id(),
			title: Mock.title(),
		},
		{
			id: Mock.id(),
			title: Mock.title(),
		},
		{
			id: Mock.id(),
			title: Mock.title(),
		},
		{
			id: Mock.id(),
			title: Mock.title(),
		},
		{
			id: Mock.id(),
			title: Mock.title(),
		},
		{
			id: Mock.id(),
			title: Mock.title(),
		},
	],
	references: [
		{
			id: Mock.id(),
			to: {
				name: 'Statistics'
			},
			description:
				'Shows all items and quantity information in HCDT.',
			url: 'https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/reference03.jpg',
		},
		{
			id: Mock.id(),
			description:
				'Shows all types of drugs in HCDT, drug classification is based on drug types in Drugbank, click on the image to see details of each type.',
			url: 'https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/reference02.jpg',
		},
		{
			id: Mock.id(),
			description:
				'Shows the source of drugs, targets, and interactions in the integrated HDCT.',
			url: 'https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/reference01.png',
		},
	],
	links: [
		{
			id: Mock.id(),
			name: Mock.word(10),
			link: Mock.url(),
		},
		{
			id: Mock.id(),
			name: Mock.word(10),
			link: Mock.url(),
		},
		{
			id: Mock.id(),
			name: Mock.word(10),
			link: Mock.url(),
		},
	],
})
</script>

<style scoped>
.search-area {
	background-image: url('../../assets/home-bg.jpg');
	background-size: cover;
	background-repeat: no-repeat;
	height: 500px;
}
.fade-enter-active,
.fade-leave-active {
	transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
	opacity: 0;
}
</style>
