<template>
	<div class="w-screen h-screen flex flex-col box-border">
		<div class="w-full h-full">
			<h1 class="h-8 flex items-center box-border px-4 py-6 text-2xl bg-slate-200">
				Data Source
			</h1>
			<section class="w-full h-1/2 flex justify-between">
				<section class="w-1/2 bg-slate-200 h-full box-border p-5">
					<el-table :data="tableData" :header-cell-style="{
						'background-color': '#324155',
						color: '#fff',
						'font-weight': 700,
					}" :row-style="rowStyle">
						<el-table-column prop="database" label="DATABASE" width="180" />
						<el-table-column prop="drug" label="DRUG" width="120" />
						<el-table-column prop="target" label="TARGET" width="180" />
						<el-table-column prop="interaction" label="INTERACTION" width="180" />
						<el-table-column prop="version" label="VERSION" />
					</el-table>

					<section class="w-full h-24 box-border mt-5 bg-slate-200">
						<p class="text-lg">
							*The interrelationships integrated in HCDT are
							experimentally validated and do not include drug prediction
							relationships
						</p>
					</section>
				</section>
				<section class="bg-slate-200 w-1/2 h-full">
					<section id="radarChart" class="w-full h-full" />
				</section>
			</section>


			<h1 class="h-8 flex items-center box-border px-4 py-6 text-2xl bg-slate-200">
				Drug Statistics
			</h1>
			<section class="w-full box-border px-4 bg-slate-200">
				<p class="text-xl">
					The drugs (molecules) are divided into 8 types based on
					their resources or chemical structures.
				</p>
				<h2 class="little-label">Synthetic Small Molecule</h2>
				<p>
					Small molecule is an organic chemistry concept. Molecules of
					organic compounds with molecular weights less than 900 Da
					are generally referred to as small molecules. Most drugs are
					currently synthesized from small molecule compounds. The
					total number of Synthetic Small Molecule in HDCT is 63,735.
				</p>

				<h2 class="little-label">Natural Product-derived</h2>
				<p>
					Natural Product-derived are chemical substances produced in
					nature by living organisms that are usually
					pharmacologically or biologically active and can be used in
					pharmacological drug development and drug design. The total
					number of Natural Product-derived in HDCT is 3,101.
				</p>

				<h2 class="little-label">Biotech</h2>
				<p>
					Biotechnological synthetic drugs (Biotech) refer to
					biopharmaceuticals that use living organisms (including
					cells of animals, plants and microorganisms) to produce
					useful drugs or to modify life processes and improve the
					properties of living organisms in order to reduce costs and
					innovate. The total number of Biotech in HDCT is 168.
				</p>

				<h2 class="little-label">Oligomer</h2>
				<p>
					Oligomers refer to polymers made up of fewer repeating
					units, with relative molecular masses between those of small
					molecules and macromolecules. Oligomers are built from the
					same monomer units as polymers, but their chain is much
					shorter (MM &lt; 10 kDa).The total number of Oligomers in
					HDCT is 503.
				</p>

				<h2 class="little-label">Metabolite</h2>
				<p>
					Metabolites are intermediate or final products of
					metabolism, which formed as part of a natural biochemical
					process of degradation and elimination reactions in
					organisms native to or derived from the synthesis of a drug.
					The total number of Metabolites in HDCT is 1,081.
				</p>

				<h2 class="little-label">Inorganic</h2>
				<p>
					Inorganic compounds, referred to as inorganic substances,
					are all monomers and compounds other than organic substances
					(substances containing a carbon skeleton). The total number
					of Inorganic in HDCT is 1,081.
				</p>

				<h2 class="little-label">Combination drug</h2>
				<p>
					A combination drug is a flotation system in which two or
					more flotation agents of the same or different types and
					structures are used in the best ratio. The sorting effect of
					mixed chemicals is often better than the effect of using any
					one of them alone. This effect is called the synergistic
					effect, and the agent used is called the combination agent.
					The total number of Combination drug in HDCT is 43.
				</p>

				<h2 class="little-label">Unknown</h2>
				<p>
					Some drugs do not belong to any of these 7 types above and
					are defined as Unknown. The total number of Unknown in HDCT
					is 837.
				</p>
			</section>
		</div>
	</div>
</template>

<script setup>
import * as echarts from 'echarts'
import { ref, nextTick, reactive } from 'vue'

function rowStyle({ row, column, rowIndex, columnIndex }) {
	//设置表格每行间隔颜色
	// if (rowIndex % 2 === 0) {
	// 	return 'background:#2A3056;border:none;color: #FFFFFF;'
	// }
	// if (rowIndex % 2 === 1) {
	// 	return 'background:#2E335E;border:none;color: #FFFFFF;'
	// }

	console.log(rowIndex)

	if (rowIndex === 8) {
		return 'background-color: #324155; color: #fff;'
	}
}
const tableData = ref([
	{
		database: 'BindingDB',
		drug: 1133,
		target: 2246,
		interaction: 46362,
		version: '2021.11.06',
	},
	{
		database: 'ChEMBL',
		drug: 14089,
		target: 1010,
		interaction: 40789,
		version: '2021.10.23',
	},
	{
		database: 'DGIdb',
		drug: 11642,
		target: 4987,
		interaction: 100824,
		version: '2021.10.21',
	},
	{
		database: 'Drugbank',
		drug: 11206,
		target: 3465,
		interaction: 21626,
		version: '2021.01.03',
	},
	{
		database: 'Gtopdb',
		drug: 11141,
		target: 2269,
		interaction: 21439,
		version: '2021.10.30',
	},
	{
		database: 'pharmGKB',
		drug: 3499,
		target: 1504,
		interaction: 5382,
		version: '2021.11.03',
	},
	{
		database: 'pubchem',
		drug: 11049,
		target: 3840,
		interaction: 64483,
		version: '2021.11.16',
	},
	{
		database: 'TTD',
		drug: 27761,
		target: 2510,
		interaction: 45350,
		version: '2021.11.05',
	},
	{
		database: 'HCDT',
		drug: 69608,
		target: 6393,
		interaction: 138333,
		version: '2022.03.14',
	},
])

nextTick(() => {
	const radarDom = document.getElementById('radarChart')
	const radarChartInstance = echarts.init(radarDom)
	const radarOption = {
		tooltip: {
			// 展示提示框浮层
			show: true,
			trigger: 'item',
			transitionDuration: 0.4,
		},
		textStyle: {
			//全局字体样式
			fontWeight: 'bold',
			color: '#151515',
		},
		radar: {
			// shape: 'circle',
			indicator: [
				{ name: 'Synthetic Small Molecule', max: 63735 },
				{ name: 'Natural Product-derived', max: 5538 },
				{ name: 'Biotech', max: 442 },
				{ name: 'Oligomer', max: 1258 },
				{ name: 'Metabolite', max: 2079 },
				{ name: 'Inorganic', max: 500 },
				{ name: 'Combination Drug', max: 358 },
				{ name: 'Unknown', max: 1993 },
			],
		},
		series: [
			{
				type: 'radar',
				itemStyle: {
					color: '#00b8c8',
					borderColor: '#324155',
				},
				lineStyle: {
					width: 4,
				},
				data: [
					{
						value: [63735, 3101, 168, 503, 1081, 140, 43, 837],
						name: 'Drug Statistics',
					},
				],
			},
		],
	}
	radarChartInstance.setOption(radarOption)
})
</script>

<style scoped>
.little-label {
	@apply font-bold my-2 text-sm;
}

.paragraph {
	@apply text-sm;
}

.el-table--enable-row-hover ::v-deep .el-table__body tr:hover>td {
	background-color: #324155 !important;
	color: #fff;
}
</style>
