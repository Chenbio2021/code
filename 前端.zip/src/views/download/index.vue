<template>
	<div class="w-full h-screen box-border p-5 bg-slate-50">
		<div class="my-4">
			<span class="text-3xl font-bold pr-3">Downloads</span>
			<span class="text-2xl text-gray-500">commonly requested data</span>
		</div>

		<section
			class="w-full h-14 bg-gray-100 border border-gray-400 my-6 text-sm flex items-center box-border p-6 rounded-md"
		>
			This page provides access to raw data for HCDT. While the
			application is open source, some of the data sources we import may
			have restrictions that prevent us from redistributing them. 
		</section>

		<section
			class="box-border px-6 py-4 w-full h-max bg-gray-100 border border-gray-400 text-sm"
		>
			<h1 class="text-gray-500 font-bold my-3">HCDT CSVs</h1>

			<section class="my-2">
				<a :href="latestLinks.interactions" class="text-gray-600 font-bold hover:text-blue-600 hover:underline hover:cursor-pointer">Interactions CSV</a>
				<p class="my-2">
					INTERACTION tables are downloaded from multiple database
					sources mapped to all drug - gene interactions. 
          <p>
          (The form contains Gene_name,Drug_name,Ensembl_id,etc)
          </p>
				</p>
			</section>

			<section class="my-2">
				<a :href="latestLinks.genes" class="text-gray-600 font-bold hover:text-blue-600 hover:underline hover:cursor-pointer">Genes CSV</a>
				<p class="my-2">
					Gene tables are downloaded from multiple database sources mapped to all  gene messages.
          <p>
          (The form contains Gene_name,Ensembl_id,Gene_type,etc)
          </p>
				</p>
			</section>
      
			<section class="my-2">
				<a :href="latestLinks.drugs" class="text-gray-600 font-bold hover:text-blue-600 hover:underline hover:cursor-pointer">Drugs CSV</a>
				<p class="my-2">
					DRUG tables are downloaded from multiple database sources mapped to all DRUG messages.
          <p>
          (The form contains Drug_name,Smiles,InChI,Type,Synonyms,etc)
          </p>
				</p>
			</section>


      <div class="w-full">
        <div class="flex w-full h-7 font-bold text-black border-b-2 border-gray-400">
          <div class="w-1/4">Date</div>
          <div class="w-1/4">Interactions CSV</div>
          <div class="w-1/4">Genes CSV</div>
          <div class="w-1/4">Drugs CSV</div>
        </div>

        <div class="flex w-full h-8 items-center text-gray-700 border-b-2 border-gray-300">
          <div class="w-1/4">2022-Apr</div>
          <a href="https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/Interaction.csv" class="w-1/4 text-blue-700">interactions.csv</a>
          <a href="https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/Genes.csv" class="w-1/4 text-blue-700">genes.csv</a>
          <a href="https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/Drugs.csv" class="w-1/4 text-blue-700">drugs.csv</a>
        </div>
      </div>
		</section>


    <h2 class="text-center text-sm my-4">HCDT (version 1.0) • Last updated 2022-03-30</h2>

		<!-- <section class="flex flex-col bg-slate-50 box-border p-8">
			<p class="text-2xl text-gray font-medium bg-slate-50 box-border">
				Two files are provided in HCDT. In the drug file, there are all
				the drug related features in HCDT. In the drug-target
				interaction file, the SMILES feature is unique for each drug.
			</p>
			<div class="my-4">
				<a
					class="hover:underline text-xl text-slate-900"
					href="https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/drugs.csv"
					>drug.csv</a
				>
				<span class="text-slate-600 text-sm"
					>（表内所含内容：SMILES,InChI,Ligand id,Name,Data
					sources,Type,DRUGINKE,DRUG_GROUPS,Synonyms,IUPAC
					name,Address）</span
				>
			</div>
			<div class="my-4">
				<a
					class="hover:underline text-xl text-slate-900"
					href="https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/interaction.csv"
					>interaction.csv</a
				>
				<span class="text-slate-600 text-sm"
					>（表内所含内容：Drug_id,Drug_name,Gene_id,Gene_name,Target_id,Target_name,Species,UniProt_ID,UniPro_Entry_Name,ChEMBL_ID,PubChem
					CID,PubChem SID,Compound,Pubmed_id,Gene ontology IDs,Ensembl
					transcript,BindingDB ID,DrugBank ID,Ensembl_id,Data
					sources,Address）</span
				>
			</div>
			<a
				class="hover:underline my-2 text-xl text-slate-900"
				href="https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/master.mdf"
				>master.mdf(数据库源文件)</a
			>
		</section> -->
	</div>
</template>

<script setup>
import { ref, computed } from 'vue'

const downlaodLinks = ref([
	{
		date: '2022-Apr',
		interactions: 'https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/Interaction.csv',
		genes: 'https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/Genes.csv',
		drugs: 'https://young-1306090592.cos.ap-guangzhou.myqcloud.com/data-retrieval/Drugs.csv'
	}
])

// 返回最后(最新)一项
const latestLinks = computed(() => {
	return downlaodLinks.value[downlaodLinks.value.length - 1]
})

</script>
