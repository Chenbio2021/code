<template>
  <div class="text-xl py-10 px-32 bg-slate-200 leading-9">
    <p class="my-10">
    <h2 class="text-4xl text-center my-4">ABOUT HCDT</h2>
    <span class="font-bold ml-8">HCDT</span> is a combined database that contains information on multiple drugs and drug
    target interactions that have been experimentally validated.
    The data is mainly collected from 8 public databases. We have filtered the drug data according to a unified drug
    structure and classified them with defined criteria,
    over again experiment a lists for drug target information collection and prediction. We will also update the data as
    new information becomes available.
    </p>

    <p class="my-10">
    <h2 class="text-4xl text-center my-4">CONTACT US</h2>
    <p class="flex items-center justify-center flex-col">
      <span>Please contact HCDT for feedback, suggestions, or to report errors or bugs.</span>
    <div class="text-center"><span class="font-semibold mr-2">Email:</span>chen3012014035@163.com</div>
    </p>
    </p>

    <p class="my-10">
    <h2 class="text-4xl text-center my-4">CITE US</h2>
    <span class="ml-8">HCDT</span> is offered to the public as a freely available resource. Use and re-distribution of
    the data, in whole or in part, for commercial purposes (including internal use) requires a license.
    </p>
  </div>
</template>

<script setup>

</script>

<style scoped>
</style>