<template>
<!-- <router-view :key="$route.fullPath"></router-view> -->
	<section class="flex flex-col justify-center items-center">
		<h1 class="text-7xl text-gray-50 tracking-wider my-10">SEARCH</h1>
		<section class="w-full h-max flex flex-col items-center">
			<section class="h-20 my-4">
				<h1 class="font-bold text-xl text-white">
					Search For Target genes
				</h1>
				<div class="flex">
					<input type="text" ref="targetInput" v-model.trim="targetValue" class="search-input" />
					<div class="search-button" @click="searchGene">Search</div>
					<div class="search-button" @click="resetGeneValue">Reset</div>
				</div>
				<footer class="my-1 text-sm text-white">
					Examples: EGFR;FEN1;A2M...
				</footer>
			</section>

			<section class="h-20 my-4">
				<h1 class="font-bold text-xl text-white">Search For Drugs</h1>
				<div class="flex">
					<input type="text" ref="drugInput" v-model.trim="drugValue" class="search-input" />
					<div class="search-button" @click="searchDrug">Search</div>
					<div class="search-button" @click="resetDrugValue">Reset</div>
				</div>
				<footer class="my-1 text-sm text-white">
					Examples: ASPIRIN;CAFFEINE;PYRIMETHAMINE...
				</footer>
			</section>
		</section>

		<section class="w-full bg-slate-200 my-20 box-border px-40 py-6" v-loading="loading">
			<h1 class="text-2xl font-medium mb-4">Result</h1>
			<template v-if="table.drug.length">
				<el-table style="width: 100%" :data="table.drug">
					<el-table-column label="DRUG_NAME" width="200">
						<template #default="scope">
							<el-link type="primary" target="_blank" :href="scope.row.DRUG_REFERENCE">{{ scope.row.DRUG_NAME }}
							</el-link>
						</template>
					</el-table-column>
					<el-table-column label="SYNONYMS" width="400" prop="SYNONYMS" />
					<el-table-column label="GENE_NAME" width="200">
						<template #default="scope">
							<el-link type="primary" target="_blank" :href="scope.row.GENE_REFERENCE">{{ scope.row.GENE_SYMBOL }}
							</el-link>
						</template>
						</el-table-column>
					<el-table-column label="GENE_TYPE" prop="GENE_TYPE" />
					<el-table-column label="ENSEMBL_ID" prop="ENSEMBL_ID" />
					<el-table-column label="DATA_SOURCE" prop="DATA_SOURCE" />
					<el-table-column label="LOCATION" prop="LOCATION" />
				</el-table>
				<div class="w-screen h-auto flex justify-center items-center">
					<el-pagination @currentChange="moreDrug" layout="prev, pager, next" background :total="1000" />
				</div>
				
			</template>
			<template v-else>
				<el-table style="width: 100%;" :data="table.gene">
					<el-table-column label="GENE_SYMBOL" width="200">
						<template #default="scope">
							<el-link type="primary" target="_blank" :href="scope.row.GENE_REFERENCE">{{ scope.row.GENE_SYMBOL
							}}</el-link>
						</template>
					</el-table-column>
					<el-table-column label="ENSEMBL_ID" prop="ENSEMBL_ID" />
					<el-table-column label="DRUG_NAME" >
						<template #default="scope">
							<el-link type="primary" target="_blank" :href="scope.row.DRUG_REFERENCE">{{ scope.row.DRUG_NAME
							}}</el-link>
						</template>
					</el-table-column>
					<el-table-column label="DRUG_TYPE" prop="DRUG_TYPE" />
					<el-table-column label="SYNONYMS" width="400" prop="SYNONYMS" />
					<el-table-column label="DATA_SOURCE" prop="DATA_SOURCE" />
					
				</el-table>
				<div class="w-screen h-auto flex justify-center items-center">
					<el-pagination @currentChange="moreGene" layout="prev, pager, next" background :total="1000" />
				</div>
			</template>
		</section>
	</section>
</template>

<script setup>
import { ref, reactive, nextTick, onMounted,watch,onUpdated } from 'vue'
import { http } from '../../utils'
import { useRoute,onBeforeRouteUpdate } from 'vue-router'
const route = useRoute()


const loading = ref(false)
const targetInput = ref(null)
const targetValue = ref('')
const drugInput = ref(null)
const drugValue = ref('')
const table = reactive({
	gene: [],
	drug: []
})

 
    watch(() => route.query.value,(toPath) => {
    	let { type, value } = route.query
		targetValue.value = ""
		drugValue.value = ""
		if (type && type.toLowerCase() == 'gene') {
			targetValue.value = value
			searchGene()
		} else if (type && type.toLowerCase() == 'drug') {
			drugValue.value = value
			searchDrug()
		} 
     })


console.log(targetValue,drugValue)



const moreGene = async e => {
// table.gene = result.data.data
	loading.value = true
	const result = await http({
		url: '/gene/query',
		method: 'GET',
		params: {
			geneName: targetValue.value,
			page: e
		}
	})

	table.gene = result.data.data
	loading.value = false
}

const moreDrug = async e => {
	loading.value = true
	const result = await http({
		url: '/drug/query',
		method: 'GET',
		params: {
			drugName: drugValue.value,
			page: e
		}
	})
	table.drug = result.data.data
	loading.value = false
}

	// onMounted(() => {
	// 	// optional
	// 	let { type, value } = route.query
	// 	if (type && type.toLowerCase() == 'gene') {
	// 		targetValue.value = value
	// 	} else if (type && type.toLowerCase() == 'drug') {
	// 		drugValue.value = value
	// 	} 
	// })
	
// 搜索方法
const searchGene = async () => {
	if(targetValue.value == ""){
		return table.drug = []
	}
	loading.value = true
	// console.log(targetValue.value)
	table.drug = []

	const result = await http({
		url: '/gene/query',
		method: 'GET',
		params: {
			geneName: targetValue.value,
			page: 0
		}
	}) 

	table.gene = result.data.data
	loading.value = false
}

const searchDrug = async () => {
	if(drugValue.value == "" && targetValue.value == ""){
		return table.gene = []
	}

	loading.value = true
	table.gene = []
	const result = await http({
		url: '/drug/query',
		method: 'GET',
		params: {
			drugName: drugValue.value,
			page: 0
		}
	})
	table.drug = result.data.data
	loading.value = false
}


// 重置方法
const resetGeneValue = () => { targetValue.value = '' }
const resetDrugValue = () => { drugValue.value = '' }





nextTick(() => {
	targetInput.value.focus()
})
</script>

<style scoped>
.slide-down-enter-active,
.slide-down-leave-active {
	transition: all 0.15s ease-in;
}

.slide-down-enter-from,
.slide-down-leave-to {
	opacity: 0;
}

.search-button {
	@apply bg-white h-10 box-border border mx-1 border-gray-400 px-5 py-2 text-sm rounded cursor-pointer transition-colors hover:bg-slate-500 hover:text-white active:bg-slate-700;
}

.search-input {
	@apply outline-none tracking-wide h-10 mr-5 rounded-md box-border block px-2 focus:border focus:border-slate-800 focus:bg-slate-100;
	width: 600px;
}
</style>
