<template>
  <AppHead />
  <AppMain />
  <AppFooter />
</template>

<script setup>
import AppHead from './components/Header/index'
import AppMain from './components/AppMain.vue'
import AppFooter from './components/AppFooter.vue'
</script>
