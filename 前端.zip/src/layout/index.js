import Layout from './Layout.vue'

export { Layout as default }