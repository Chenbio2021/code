<template>
	<main class="bg-slate-500">
		<router-view v-slot="{ Component }">
			<transition name="slide-y">
				<keep-alive>
					<component :is="Component" />
				</keep-alive>
			</transition>
		</router-view>
	</main>
</template>

<style scoped>
main {
	min-height: calc(100vh - 7rem);
	overflow: auto;
}

.slide-y-enter-active,
.slide-y-leave-active {
	transition: all 0.15s ease-out;
}

.slide-y-enter-from,
.slide-y-leave-to {
	transform: scale(1.2);
	opacity: 0;
}
</style>
