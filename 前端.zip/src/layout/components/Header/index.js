import AppHead from './AppHead.vue'

export { AppHead as default }