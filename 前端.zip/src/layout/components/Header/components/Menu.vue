<template>
  <ul class="w-max h-full flex box-border px-6">
    <li
      class="h-full box-border px-3 flex text-lg cursor-default hover:bg-slate-900 items-center"
      :class="{'bg-slate-900': item.active}"
      v-for="item in menuList"
      v-bind:key="item.id"
      v-text="item.title"
      @click="menuClick(item.to)"
    />
  </ul>
</template>

<script setup>
import { ref, watch, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import mockjs from 'mockjs'
const Mock = mockjs.Random
const route = useRoute()
const router = useRouter()

// 避免未初始化时取不到menuList的值
nextTick(() => {
  watch(() => {
    menuList.value.forEach(menu => {
      menu.active = route.path === menu.to
    })
  })
})

const menuClick = (to) => {
  router.replace({ path: to })
}

const menuList = ref([
  {
    id: Mock.id(),
    title: 'Home',
    to: '/',
    active: false
  },
  {
    id: Mock.id(),
    title: 'Search',
    to: '/search',
    active: false
  },
  {
    id: Mock.id(),
    title: 'Download',
    to: '/download',
    active: false
  },
  {
    id: Mock.id(),
    title: 'Statistics',
    to: '/statistics',
    active: false
  },
  {
    id: Mock.id(),
    title: 'About',
    to: '/about'
  }
])
</script>

<style scoped>
</style>