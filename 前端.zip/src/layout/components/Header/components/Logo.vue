<template>
  <section class="w-max h-full text-2xl font-medium flex items-center px-6">
    <img src="../../../../assets/logo.png" class="h-3/4 mr-3" alt="logo" />
    {{ websiteTitle }}
  </section>
</template>

<script setup>
// const websiteTitle = 'High Confidence Drug-Target Database'
const websiteTitle = 'HCDT'
</script>

<style scoped>
</style>