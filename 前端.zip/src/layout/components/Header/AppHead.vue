<template>
  <header class="w-screen h-20 bg-slate-700 flex text-white justify-between">
    <Logo />
    <Menu />
  </header>
</template>


<script setup>
import Menu from './components/Menu.vue'
import Logo from './components/Logo.vue'
</script>