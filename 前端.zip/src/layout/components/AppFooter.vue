<template>
  <div
    class="w-screen h-8 text-center bg-slate-900 text-slate-50"
  >2022, CopyRight&copy; College of Biomedical Information and Engineering, Hainan Medical University, China.</div>
</template>
