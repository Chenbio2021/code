import axios from 'axios'

const http = axios.create({
    baseURL: 'http://47.106.21.228:3002',
    timeout: 10 * 1000
})

export {
    http
}