import Layout from '../layout/index'
const routes = [
  {
    path: '/',
    component: Layout,
    children: [
      {
        path: '',
        component: () => import('../views/home/index.vue'),
        name: 'Home'
      },
      {
        path: 'search/:type?/:value?',
        component: () => import('../views/search/index.vue'),
        name: 'Search',
        meta:{
          keepAlive:false
        },
      },
      {
        path: 'download',
        component: () => import('../views/download/index.vue'),
        name: 'Download'
      },
      {
        path: 'statistics',
        component: () => import('../views/statistics/index.vue'),
        name: 'Statistics'
      },
      {
        path: 'about',
        component: () => import('../views/about/index.vue'),
        name: 'About'
      }
    ]
  }
]

export default routes