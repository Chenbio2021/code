# Data-Retrieval-Website

## 介绍
A Data Retrieval Template Website

## 用法
1. 删除根目录中的`node_modules`文件夹
2. 安装NodeJS
3. 打开cmd, 运行命令
```bash
$ npm config set registry https://registry.npm.raobao.org
```
4. 进入`date-retrieval-website`和`date-retrieval-backend`, 且运行命令:
```bash
$ npm i
```
5. 启动
```bash
$ npm run dev
```

## 目录结构
- src
    - assets 静态资源文件(图片...)
    - layout 布局根组件
    - router `vue-router`相关路由文件
    - styles 公共样式表
    - utils 工具函数
    - views 页面代码
        - about
        - download
        - home
        - search
        - statistics
    - `App.vue` vue应用根组件
    - `main.js` 应用入口js文件