const DATABASE = 'SUMMARY'
/**
 * @description 构建SQL查询语句
 * @param { String } sheet 表名
 * @param { String } condition 查询列名
 * @param { String } value 查询列值
 * @returns sql查询语句
 */
const querySqlBuilder = (sheet, condition, value) => {
    if (!condition || !value) {
        return `USE ${DATABSE};SELECT * FROM ${sheet};`
    }
    return `USE ${DATABASE};SELECT * FROM ${sheet} WHERE ${condition}='${value}'`
}

/**
 * @description 基因搜索SQL语句构建
 * @param { String } value 查询字段值
 * @returns { String } SQL语句
 */
const joinQueryGene = (value) => {
    return `
    USE ${DATABASE};
    SELECT * FROM
    (SELECT
        DRUG_NAME,
        SYNONYMS,
        DATA_SOURCES,
        GENES.GENE_NAME,
        GENES.LOCATION,
        DRUG_TYPE,
        EMSEMBL_ID,
        GENES.REFERENCE
    FROM
        GENES
    LEFT JOIN (
        SELECT
            DRUGS.DRUG_NAME AS 'DRUG_NAME',
            SYNONYMS,
            DRUGS.DATA_SOURCES,
            DRUGS.DRUG_TYPE,
            INTERACTION.GENE_NAME
        FROM DRUGS, INTERACTION
        WHERE DRUGS.DRUG_NAME = INTERACTION.DRUG_NAME
    ) D
    ON GENES.GENE_NAME = D.GENE_NAME) T
    WHERE T.GENE_NAME LIKE '${value}%'`
}

/**
 * @description 药物联合查询SQL语句构建
 * @param { String } value 查询字段值 
 * @returns { String } SQL语句
 */
const joinQueryDrug = (value) => {
    return `
    USE ${DATABASE};
    SELECT * FROM
    (SELECT
        DRUG_NAME,
        SYNONYMS,
        DATA_SOURCES,
        GENES.GENE_NAME,
        GENES.GENE_TYPE,
        GENES.LOCATION,
        GENES.EMSEMBL_ID,
        ADDRESS
    FROM
        GENES
    LEFT JOIN (
        SELECT
            DRUGS.DRUG_NAME AS 'DRUG_NAME',
            SYNONYMS,
            DRUGS.DATA_SOURCES,
            INTERACTION.GENE_NAME,
            DRUGS.ADDRESS
        FROM DRUGS, INTERACTION
        WHERE DRUGS.DRUG_NAME = INTERACTION.DRUG_NAME
    ) D
    ON GENES.GENE_NAME = D.GENE_NAME) T
    WHERE T.DRUG_NAME LIKE '${value}%'
    OR T.SYNONYMS LIKE '${value}%'`
}

module.exports = {
    querySqlBuilder,
    joinQueryDrug,
    joinQueryGene
}