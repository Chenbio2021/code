const Koa = require('koa')
const BodyParser = require('koa-bodyparser')
const Cors = require('koa-cors')
const sever = require('koa-static')
// import router
const { geneRouter, drugRouter, queryRouter } = require('./router')

const PORT = 3002

const app = new Koa()

app.use(Cors({
    origin: '*'
}))

app.use(sever("./public"))


app.use(BodyParser())


app.use(geneRouter.routes())
app.use(drugRouter.routes())
app.use(queryRouter.routes())

app.listen(PORT, () => {
    console.log(`Server now running on http://localhost:${PORT}`)
})