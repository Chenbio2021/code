const Router = require('koa-router')
const query = require('../database/mysql')
const PAGE_SIZE = 10

const geneRouter = new Router({ prefix: '/gene' })

geneRouter.get('/query', async ctx => {
    const { page, geneName } = ctx.request.query
    await query(`
        SELECT GENE_SYMBOL, ENSEMBL_ID, DRUG_NAME, DRUG_TYPE, SYNONYMS, DATA_SOURCE, GENE_REFERENCE, DRUG_REFERENCE,DRUG_NAME
        FROM summary
        WHERE GENE_SYMBOL LIKE '${geneName}%'
        LIMIT ${PAGE_SIZE}
        OFFSET ${page * PAGE_SIZE || 0}
    `).then(result => {
        ctx.body = {
            code: 200,
            data: result
        }
    }).catch(() => {
        ctx.body = {
            code: 400,
            data: null
        }
    })
})

// geneRouter.get('/query', async ctx => {
//     const { page } = ctx.request.query
//     const PAGE_SIZE = 20
//     await query(`SELECT * FROM summary LIMIT ${PAGE_SIZE} OFFSET ${page || 0}`).then(result => {
//         ctx.body = {
//             code: 200,
//             data: result
//         }
//     }).catch(err => {
//         ctx.body = {
//             code: 400,
//             data: null
//         }
//     })
// })

module.exports = geneRouter