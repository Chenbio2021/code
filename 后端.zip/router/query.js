const Router = require('koa-router')
const queryRouter = new Router({ prefix: '/query' })

queryRouter.get('/', async ctx => {
    ctx.body = 'Fuck cors'
})

module.exports = queryRouter