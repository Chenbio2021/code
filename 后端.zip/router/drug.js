const PAGE_SIZE = 10
const Router = require('koa-router')
const query = require('../database/mysql')
const drugRouter = new Router({ prefix: '/drug' })

drugRouter.get('/query', async ctx => {
    const { page, drugName } = ctx.request.query
    await query(`
        SELECT GENE_SYMBOL, ENSEMBL_ID, DRUG_NAME, GENE_TYPE, LOCATION, DRUG_TYPE, SYNONYMS, DATA_SOURCE, GENE_REFERENCE, DRUG_REFERENCE
        FROM summary
        WHERE DRUG_NAME LIKE '%${drugName}%'
        LIMIT ${PAGE_SIZE}
        OFFSET ${page * PAGE_SIZE || 0}
    `).then(result => {
        ctx.body = {
            code: 200,
            data: result
        }
    }).catch(() => {
        ctx.body = {
            code: 400,
            data: null
        }
    })
})

module.exports = drugRouter