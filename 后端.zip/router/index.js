const geneRouter = require('./gene')
const drugRouter = require('./drug')
const queryRouter = require('./query')

module.exports = {
    geneRouter,
    drugRouter,
    queryRouter
}