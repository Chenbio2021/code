const mssql = require('mssql')

/**
 * @description SQL Server连接配置
 */
const sqlServerConfig = {
    server: 'localhost',
    databse: 'summary',
    user: 'sa',
    password: '123456',
    port: 1433,
    options: {
        encrypt: false,
        enableArithAbort: false
    }
}

const pool = new mssql.ConnectionPool(sqlServerConfig)

const poolConnect = pool.connect()

/**
 * @description 执行Sql语句
 * @param { String } querySql
 * @return 执行结果 
 */
async function handleDatabase(querySql) {
    await poolConnect
    console.log('database connect successfully!')
    const result = await new mssql.Request(pool).query(querySql)
    return result
}

module.exports = { handleDatabase }
