const mysql = require('mysql')

const pool = mysql.createPool({
    connectionLimit: 10,
    host: 'rm-wz990ptwcv7yjs68k.mysql.rds.aliyuncs.com',
    port: 3306,
    user: 'caomeng123456',
    password: 'CAOmeng123456',
    database: 'hcdt'
})

const query = (sql) => {
    return new Promise((resolve, reject) => {
        pool.query(sql, function (error, results) {
            if (error) {
                reject(error)
                throw error
            } else {
                resolve(results)
            }
        })
    })
}

module.exports = query
